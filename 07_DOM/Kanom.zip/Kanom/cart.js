let productInCart = [];

//function chackAndAdd() 
export function chackAndAdd(kanomId, kanom, price) {
    for(let pro of productInCart){
        if (pro.includes(kanom)) {
            pro[3]++;
        } else {
            productInCart.push([kanomId, kanom, price, 1]);
        }
    }
    
}

// function showCart() 
export function showCart() {
    let x = productInCart.join();
    alert('พริ้วสุดเวะซี่'+ x);



    // const divProductEle = document.querySelector("#product");
    // divProductEle.textContent = '';
    // for (let i = 0; i < productInCart.length; i++) {
    //     //สร้าง div กําหนด attribute ของ id เเละตกเเต่งจัดระยะด้วย bootstrap
    //     const divCarEle = document.createElement("div");
    //     // divCarEle.setAttribute("class", "car");
    //     // divCarEle.setAttribute("class", "px-1 mx-1 div-link");
    //     divCarEle.setAttribute("class", "card");
    //     // divCarEle.setAttribute("small class", "text-muted");
    //     divCarEle.setAttribute("style", "width: 18rem");
    //     divCarEle.setAttribute("id", productInCart[i]);

    //     //สร้าง tag img กําหนด attribute src เพื่อนํา path file ของรูปภาพมาใส่ เเละกําหนดความกว้างความสูงของรูป
    //     //กําหนดให้ pCarImageEle เป็น child ของ div divCarEle
    //     pCarImageEle.setAttribute("height", 150);
    //     pCarImageEle.setAttribute("width", 270);
    //     pCarImageEle.setAttribute("class","card-img-top");
    //     divCarEle.appendChild(pCarImageEle);

    //     //สร้าง tag h3 เพื่อแสดงชื่อของรถเป็น heading3
    //     //กําหนดให้ h3CarNameEle เป็น child ของ div divCarEle
    //     const h3CarNameEle = document.createElement("h3");
    //     h3CarNameEle.setAttribute("class", "card-title");
    //     h3CarNameEle.textContent = productInCart[i].carName;
    //     divCarEle.appendChild(h3CarNameEle);

    //     //สร้าง tag p เพื่อแสดง color ของรถเป็น p
    //     //กําหนดให้ pCarColorEle เป็น child ของ div divCarEle
    //     const pCarColorEle = document.createElement("p");
    //     pCarColorEle.textContent = "Color: " + productInCart[i].color;
    //     pCarColorEle.setAttribute("class", "card-text");
    //     divCarEle.appendChild(pCarColorEle);

    //     //สร้าง tag p เพื่อแสดง price ของรถเป็น p
    //     //กําหนดให้ pCarPriceEle เป็น child ของ div divCarEle
    //     const pCarPriceEle = document.createElement("p");
    //     pCarPriceEle.textContent = "Price: " + productInCart[i].price;
    //     pCarPriceEle.setAttribute("class", "card-text");
    //     divCarEle.appendChild(pCarPriceEle);

    //     const addCarEle = document.createElement("button");
    //     addCarEle.setAttribute("id","addToCart");
    //     addCarEle.textContent = "Add to cart";
    //     divCarEle.appendChild(addCarEle);

    //     addCarEle.addEventListener('click', () => {
    //         alert(`add car name : ${arr[i].carName}`);

    //         let newItem = {id: productInCart[i].carId, name: productInCart[i].carName, color: productInCart[i].color, qty: 1};

    //         if(carts.items.length == 0 || carts.itemId.includes(newItem.id) == false) {
    //             carts.items.push(newItem);
    //             carts.itemId.push(newItem.id);
    //         } else {
    //             for(let i = 0; i < carts.items.length; i++) {
    //                 if(newItem.id == carts.items[i].id) {
    //                     carts.items[i].qty += 1;
    //                 }
    //             }
    //         }

    //         carts.totalQty = carts.items.reduce((sum, item) => {return sum += item.qty}, 0);
    //         const amount = document.querySelector('#num');
    //         amount.textContent = carts.totalQty;
    //         console.log(carts);

    //     })

    //     //กําหนดให้ divCarEle เป็น child ของ div divCarsEle
    //     divProductEle.appendChild(divCarEle);

    // } 
}








// //Add number of products in cart
//     let navBarNumCart = document.createElement('span');
//     navBarNumCart.setAttribute('id','numCart');
//     navBarNumCart.setAttribute('style','font-size: 20px')
//     navBarNumCart.appendChild(document.createTextNode(0));
//     navBarCart.appendChild(navBarNumCart);
//     navBarCart.appendChild(document.createTextNode(' products in cart '))
// //Add trash button for empty the cart
//     let navBarTrashButton = document.createElement('button');
//     navBarTrashButton.setAttribute('id','trash');
//     navBarTrashButton.setAttribute('class','btn btn-primary');
//     navBarTrashButton.setAttribute('style','border-color:#fff')
//     let trash = document.createElement('img')
//     trash.setAttribute('src','image/bin.png')
//     trash.setAttribute('style','width:2em;height:2em');
//     navBarTrashButton.appendChild(trash)
//     navBarCart.appendChild(navBarTrashButton)
//     divNavRow.appendChild(navBarCart);